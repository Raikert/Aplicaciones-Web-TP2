﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Aplicaciones_Web___TP2
{
    public partial class Ejercicio1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }

        protected void btnInicio_Click(object sender, EventArgs e)
        {
            Response.Redirect("Inicio.aspx");
        }

        protected void btnGuardar2_Click(object sender, EventArgs e)
        {
            lblMensaje.Text = "Bienvenido Usuario " + txtNombre.Text;
        }

        protected void btnGuardar1_Click(object sender, EventArgs e)
        {
            bool validator = true;

            for(int i=1;i<ddlLocalidades.Items.Count;i++) 
            {
                if (ddlLocalidades.Items[i].Text == txtLocalidad.Text)
                    validator = false;
            }

            if(validator)
                ddlLocalidades.Items.Add(txtLocalidad.Text);
        }
    }
}